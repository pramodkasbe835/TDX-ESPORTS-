package com.tdx.esports;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
